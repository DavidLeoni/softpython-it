
NOTE TO MYSELF: this dir is gitignored, I keep preparation stuff in english version

