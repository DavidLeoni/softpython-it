

class MyClass:

    """ 
        This class does... stuff
    """
    def do_something(self):
        """ Does something """
        raise Exception("TODO IMPLEMENT ME !!!")
 
    def do_something_else(self):
        """ Does something else """
        raise Exception("TODO IMPLEMENT ME !!!")

