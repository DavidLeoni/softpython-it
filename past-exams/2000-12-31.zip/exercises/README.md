
In this directory will go files files for the students to edit, like 

- exercise1.py
- exercise1_test.py
- exercise2.py
- exercise2_test.py
.
.
.

