

class MyClass:

    """ 
        This class does... stuff
    """
    def do_something(self):
        print("Doing something")
 
    def do_something_else(self):
        """ Does something else """
        print("Doing something else")
